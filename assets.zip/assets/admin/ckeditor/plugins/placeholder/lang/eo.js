﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","eo",{title:"Atributoj de la rezervita spaco",toolbar:"Rezervita Spaco",name:"Nomo de la rezervita spaco",invalidName:"La rezervita spaco ne povas esti malplena kaj ne povas enteni la sekvajn signojn : [, ], \x3c, \x3e",pathName:"rezervita spaco"});